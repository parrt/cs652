package symtab;

public interface Type {
	String getTypeName();
}
